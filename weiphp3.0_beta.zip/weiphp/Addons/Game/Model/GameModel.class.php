<?php

namespace Addons\Game\Model;
use Think\Model;

/**
 * Game模型
 */
class GameModel extends Model{

}
