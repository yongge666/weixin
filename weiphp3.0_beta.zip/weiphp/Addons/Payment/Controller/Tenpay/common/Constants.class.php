<?php
//---------------------------------------------------------
//基础类，定义相关参数
//---------------------------------------------------------
namespace Addons\Payment\Controller;
class Constants {
	
	/** 编码 */
	var $DEFAULT_CHARSET = "GBK";
	
	var $RETCODE_OK = "0";
	var $PAY_RESULT_OK = "0";
	
}

?>