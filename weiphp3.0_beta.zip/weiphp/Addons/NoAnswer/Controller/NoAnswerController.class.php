<?php

namespace Addons\NoAnswer\Controller;
use Home\Controller\AddonsController;

class NoAnswerController extends AddonsController{

}
