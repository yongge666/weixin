<?php

namespace Addons\NoAnswer\Model;
use Think\Model;

/**
 * NoAnswer模型
 */
class NoAnswerModel extends Model{

}
