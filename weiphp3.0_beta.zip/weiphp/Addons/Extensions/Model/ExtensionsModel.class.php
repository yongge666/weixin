<?php

namespace Addons\Extensions\Model;
use Think\Model;

/**
 * Extensions模型
 */
class ExtensionsModel extends Model{

}
