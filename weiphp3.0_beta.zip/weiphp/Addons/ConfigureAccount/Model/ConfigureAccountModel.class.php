<?php

namespace Addons\ConfigureAccount\Model;
use Think\Model;

/**
 * ConfigureAccount模型
 */
class ConfigureAccountModel extends Model{
}
