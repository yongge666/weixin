<?php

namespace Addons\BusinessCard\Model;
use Think\Model;

/**
 * BusinessCard模型
 */
class BusinessCardModel extends Model{

}
