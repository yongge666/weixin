<?php
return array (
		'title' => '贴边风格',
		'author' => 'jacy',
		'desc' => ''
);					