<?php
return array (
		'min_time' => array (
				'title' => '评论防刷屏设置:',
				'type' => 'text',
				'value' => '30',
				'tip' => '同一用户发表评论的时间间隔，单位为秒' 
		),
		'limit' => array (
				'title' => '评论展示数量:',
				'type' => 'text',
				'value' => '20',
				'tip' => '用户查看评论时，展示最新评论的数量' 
		) 
);
					