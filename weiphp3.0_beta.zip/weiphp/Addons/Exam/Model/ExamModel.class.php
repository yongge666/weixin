<?php

namespace Addons\Exam\Model;
use Think\Model;

/**
 * Exam模型
 */
class ExamModel extends Model{

}
