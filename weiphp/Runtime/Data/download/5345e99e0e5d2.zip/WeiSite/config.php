<?php
return array (
		'title' => array (
				'title' => '封面标题:',
				'type' => 'text',
				'value' => '点击进入首页',
				'tip' => '' 
		),
		'cover' => array (
				'title' => '封面图片:',
				'type' => 'picture',
				'value' => '',
				'tip' => '' 
		),
		'info' => array (
				'title' => '封面简介:',
				'type' => 'textarea',
				'value' => '',
				'tip' => '' 
		),
		'background' => array (
				'title' => '模板背景图:',
				'type' => 'picture',
				'value' => '',
				'tip' => '为空时默认使用模板里的背景图片'
		),	
					
		'code' => array (
				'title' => '统计代码:',
				'type' => 'textarea',
				'value' => '',
				'tip' => '' 
		) ,
		'template_index' => array (
				'title' => '首页模板',
				'type' => 'hidden',
				'value' => 'ColorV1',
				'tip' => ''
		),
		'template_footer' => array (
				'title' => '底部模板',
				'type' => 'hidden',
				'value' => 'V1',
				'tip' => ''
		),
		'template_lists' => array (
				'title' => '图文列表模板',
				'type' => 'hidden',
				'value' => 'V1',
				'tip' => ''
		),
		'template_detail' => array (
				'title' => '图文内容模板',
				'type' => 'hidden',
				'value' => 'V1',
				'tip' => ''
		)	
);
					