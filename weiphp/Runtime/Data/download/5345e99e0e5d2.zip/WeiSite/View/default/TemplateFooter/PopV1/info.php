<?php
return array (
		'title' => '弹出式菜单v-1',
		'author' => 'jacy',
		'desc' => '菜单图标为40X40以上'
);					