<?php
return array (
		'title' => '详情v-3',
		'author' => 'jacy',
		'desc' => ''
);					