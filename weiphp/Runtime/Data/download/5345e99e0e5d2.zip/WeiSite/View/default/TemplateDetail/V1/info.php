<?php
return array (
		'title' => '详情v-1',
		'author' => 'jacy',
		'desc' => ''
);					