<?php
return array (
		'title' => '大背景图首页V-1',
		'author' => 'jacy',
		'desc' => '必须上传大图背景 不显示banner无需添加banner'
);					