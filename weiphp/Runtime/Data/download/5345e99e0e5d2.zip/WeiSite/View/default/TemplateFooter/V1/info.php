<?php
return array (
		'title' => '简约黑色底部菜单',
		'author' => 'jacy',
		'desc' => '菜单不需要图标'
);					