<?php
return array (
		'title' => '相册列表模板V-1',
		'author' => 'jacy',
		'desc' => ''
);					