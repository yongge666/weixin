<?php
return array (
		'title' => '没有底部菜单',
		'author' => 'jacy',
		'desc' => '选择此模板将不会显示底部菜单'
);					