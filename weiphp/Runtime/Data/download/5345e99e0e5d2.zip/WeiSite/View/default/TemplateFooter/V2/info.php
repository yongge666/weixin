<?php
return array (
		'title' => '带图标黑色底部菜单',
		'author' => 'jacy',
		'desc' => '菜单图标为30X30以上'
);					