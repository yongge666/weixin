<?php
return array (

  'need_trueljinfo' => array (

    'title' => '实物是否需要填写领奖信息:',

    'type' => 'radio',

    'options' => array (

      '1' => '是',

      '0' => '否'

    ),

    'value' => '1'

  ));
					